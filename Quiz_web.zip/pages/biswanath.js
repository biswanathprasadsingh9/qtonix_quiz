import React from 'react'
import { connect } from 'react-redux'

export const biswanath = (props) => {
  return (
    <div>biswanath</div>
  )
}

const mapStateToProps = (state) => ({})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(biswanath)