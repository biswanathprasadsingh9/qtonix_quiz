import React, { Component } from 'react'

export class videoplay extends Component {

    constructor(props){
        super(props)
        this.state={
            autoplay:false
        }
    }

  render() {
    return (
      <div>

        
      </div>
    )
  }
}

export default videoplay