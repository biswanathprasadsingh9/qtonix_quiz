"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/videoplay";
exports.ids = ["pages/videoplay"];
exports.modules = {

/***/ "./pages/videoplay.js":
/*!****************************!*\
  !*** ./pages/videoplay.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"videoplay\": () => (/* binding */ videoplay)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass videoplay extends react__WEBPACK_IMPORTED_MODULE_1__.Component {\n    constructor(props){\n        super(props);\n        this.state = {\n            autoplay: false\n        };\n    }\n    render() {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                children: \"Play Video\"\n            }, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\videoplay.js\",\n                lineNumber: 19,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\videoplay.js\",\n            lineNumber: 14,\n            columnNumber: 7\n        }, this);\n    }\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (videoplay);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy92aWRlb3BsYXkuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFBd0M7QUFFakMsTUFBTUUsU0FBUyxTQUFTRCw0Q0FBUztJQUVwQ0UsWUFBWUMsS0FBSyxDQUFDO1FBQ2QsS0FBSyxDQUFDQSxLQUFLLENBQUM7UUFDWixJQUFJLENBQUNDLEtBQUssR0FBQztZQUNQQyxRQUFRLEVBQUMsS0FBSztTQUNqQjtLQUNKO0lBRUhDLE1BQU0sR0FBRztRQUNQLHFCQUNFLDhEQUFDQyxLQUFHO3NCQUtGLDRFQUFDQyxRQUFNOzBCQUFDLFlBQVU7Ozs7O29CQUFTOzs7OztnQkFDdkIsQ0FDUDtLQUNGO0NBQ0Y7QUFFRCxpRUFBZVAsU0FBUyIsInNvdXJjZXMiOlsid2VicGFjazovL2FkbWluLy4vcGFnZXMvdmlkZW9wbGF5LmpzPzA4ZWEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xyXG5cclxuZXhwb3J0IGNsYXNzIHZpZGVvcGxheSBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJvcHMpe1xyXG4gICAgICAgIHN1cGVyKHByb3BzKVxyXG4gICAgICAgIHRoaXMuc3RhdGU9e1xyXG4gICAgICAgICAgICBhdXRvcGxheTpmYWxzZVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgcmVuZGVyKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuXHJcbiAgICAgICAgXHJcblxyXG5cclxuICAgICAgICA8YnV0dG9uPlBsYXkgVmlkZW88L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB2aWRlb3BsYXkiXSwibmFtZXMiOlsiUmVhY3QiLCJDb21wb25lbnQiLCJ2aWRlb3BsYXkiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJhdXRvcGxheSIsInJlbmRlciIsImRpdiIsImJ1dHRvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/videoplay.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/videoplay.js"));
module.exports = __webpack_exports__;

})();