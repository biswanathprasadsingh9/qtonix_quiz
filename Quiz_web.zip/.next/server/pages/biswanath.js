"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/biswanath";
exports.ids = ["pages/biswanath"];
exports.modules = {

/***/ "./pages/Test.js":
/*!***********************!*\
  !*** ./pages/Test.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Test\": () => (/* binding */ Test),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass Test extends react__WEBPACK_IMPORTED_MODULE_1__.Component {\n    constructor(props){\n        super(props);\n        this.state = {\n            name: \"Biswanath\",\n            show: false\n        };\n    }\n    chnageName = ()=>{\n        this.setState({\n            show: true\n        });\n    };\n    render() {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: [\n                this.state.show ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                    children: this.state.name\n                }, void 0, false, {\n                    fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\Test.js\",\n                    lineNumber: 30,\n                    columnNumber: 9\n                }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: this.chnageName,\n                    children: \"Change Name\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\Test.js\",\n                    lineNumber: 35,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\Test.js\",\n            lineNumber: 26,\n            columnNumber: 7\n        }, this);\n    }\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Test);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9UZXN0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQXdDO0FBR2pDLE1BQU1FLElBQUksU0FBU0QsNENBQVM7SUFHL0JFLFlBQVlDLEtBQUssQ0FBQztRQUNkLEtBQUssQ0FBQ0EsS0FBSyxDQUFDO1FBQ1osSUFBSSxDQUFDQyxLQUFLLEdBQUM7WUFDUEMsSUFBSSxFQUFDLFdBQVc7WUFDaEJDLElBQUksRUFBQyxLQUFLO1NBQ2I7S0FDSjtJQUdEQyxVQUFVLEdBQUMsSUFBSTtRQUNYLElBQUksQ0FBQ0MsUUFBUSxDQUFDO1lBQ1ZGLElBQUksRUFBQyxJQUFJO1NBQ1osQ0FBQztLQUNMO0lBSUhHLE1BQU0sR0FBRztRQUNQLHFCQUNFLDhEQUFDQyxLQUFHOztnQkFFRCxJQUFJLENBQUNOLEtBQUssQ0FBQ0UsSUFBSSxpQkFFaEIsOERBQUNLLEdBQUM7OEJBQUUsSUFBSSxDQUFDUCxLQUFLLENBQUNDLElBQUk7Ozs7O3dCQUFLLGlCQUV4Qiw2SUFBSzs4QkFHTCw4REFBQ08sUUFBTTtvQkFBQ0MsT0FBTyxFQUFFLElBQUksQ0FBQ04sVUFBVTs4QkFBRSxhQUFXOzs7Ozt3QkFBUzs7Ozs7O2dCQUVsRCxDQUNQO0tBQ0Y7Q0FDRjtBQUVELGlFQUFlTixJQUFJIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWRtaW4vLi9wYWdlcy9UZXN0LmpzPzU3NjgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xyXG5cclxuXHJcbmV4cG9ydCBjbGFzcyBUZXN0IGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcblxyXG4gICAgY29uc3RydWN0b3IocHJvcHMpe1xyXG4gICAgICAgIHN1cGVyKHByb3BzKVxyXG4gICAgICAgIHRoaXMuc3RhdGU9e1xyXG4gICAgICAgICAgICBuYW1lOidCaXN3YW5hdGgnLFxyXG4gICAgICAgICAgICBzaG93OmZhbHNlLFxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgY2huYWdlTmFtZT0oKT0+e1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgICAgICBzaG93OnRydWVcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcblxyXG4gICAgICAgIHt0aGlzLnN0YXRlLnNob3dcclxuICAgICAgICA/XHJcbiAgICAgICAgPHA+e3RoaXMuc3RhdGUubmFtZX08L3A+XHJcbiAgICAgICAgOlxyXG4gICAgICAgIDw+PC8+XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RoaXMuY2huYWdlTmFtZX0+Q2hhbmdlIE5hbWU8L2J1dHRvbj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGVzdCJdLCJuYW1lcyI6WyJSZWFjdCIsIkNvbXBvbmVudCIsIlRlc3QiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJuYW1lIiwic2hvdyIsImNobmFnZU5hbWUiLCJzZXRTdGF0ZSIsInJlbmRlciIsImRpdiIsInAiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/Test.js\n");

/***/ }),

/***/ "./pages/biswanath.js":
/*!****************************!*\
  !*** ./pages/biswanath.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ biswanath)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Test__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Test */ \"./pages/Test.js\");\n\n\n\nfunction biswanath() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Test__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n                lineNumber: 8,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Test__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n                lineNumber: 9,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Test__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n                lineNumber: 10,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Test__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n                lineNumber: 11,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Test__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n                lineNumber: 12,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\_____qtonix_project\\\\quiz\\\\web\\\\pages\\\\biswanath.js\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9iaXN3YW5hdGguanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFBeUI7QUFDQTtBQUVWLFNBQVNFLFNBQVMsR0FBRztJQUNsQyxxQkFDRSw4REFBQ0MsS0FBRzs7MEJBRUEsOERBQUNGLDZDQUFJOzs7O29CQUFHOzBCQUNSLDhEQUFDQSw2Q0FBSTs7OztvQkFBRzswQkFDUiw4REFBQ0EsNkNBQUk7Ozs7b0JBQUc7MEJBQ1IsOERBQUNBLDZDQUFJOzs7O29CQUFHOzBCQUNSLDhEQUFDQSw2Q0FBSTs7OztvQkFBRzs7Ozs7O1lBRU4sQ0FDUDtDQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWRtaW4vLi9wYWdlcy9iaXN3YW5hdGguanM/ZWI4OSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCBUZXN0IGZyb20gJy4vVGVzdCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJpc3dhbmF0aCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuXHJcbiAgICAgICAgPFRlc3QgLz5cclxuICAgICAgICA8VGVzdCAvPlxyXG4gICAgICAgIDxUZXN0IC8+XHJcbiAgICAgICAgPFRlc3QgLz5cclxuICAgICAgICA8VGVzdCAvPlxyXG5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJUZXN0IiwiYmlzd2FuYXRoIiwiZGl2Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/biswanath.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/biswanath.js"));
module.exports = __webpack_exports__;

})();